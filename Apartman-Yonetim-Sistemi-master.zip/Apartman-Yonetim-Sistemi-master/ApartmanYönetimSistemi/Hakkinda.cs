﻿using System;
using System.Windows.Forms;

namespace ApartmanYönetimSistemi
{
	public partial class Hakkinda : Form
	{
		public Hakkinda()
		{
			InitializeComponent();
		}

		private void bt_aracGoruntule_Click(object sender, EventArgs e) => this.Close();
	}
}
