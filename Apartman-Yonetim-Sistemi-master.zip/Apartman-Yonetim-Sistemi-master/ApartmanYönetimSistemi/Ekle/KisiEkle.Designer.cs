﻿namespace ApartmanYönetimSistemi
{
	partial class KisiEkle
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lb_sahipSakin = new System.Windows.Forms.Label();
			this.cb_sahipSakin = new System.Windows.Forms.ComboBox();
			this.lb_ad = new System.Windows.Forms.Label();
			this.lb_soyad = new System.Windows.Forms.Label();
			this.tb_ad = new System.Windows.Forms.TextBox();
			this.tb_soyad = new System.Windows.Forms.TextBox();
			this.lb_telefon = new System.Windows.Forms.Label();
			this.tb_telno1 = new System.Windows.Forms.TextBox();
			this.lb_isAdresi = new System.Windows.Forms.Label();
			this.tb_isAdresi = new System.Windows.Forms.TextBox();
			this.lb_aciklama = new System.Windows.Forms.Label();
			this.tb_aciklama = new System.Windows.Forms.TextBox();
			this.bt_onayla = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.tb_telno2 = new System.Windows.Forms.TextBox();
			this.tb_telno3 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.tb_eposta = new System.Windows.Forms.TextBox();
			this.lb_eposta = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lb_sahipSakin
			// 
			this.lb_sahipSakin.AutoSize = true;
			this.lb_sahipSakin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lb_sahipSakin.ForeColor = System.Drawing.Color.MidnightBlue;
			this.lb_sahipSakin.Location = new System.Drawing.Point(34, 51);
			this.lb_sahipSakin.Name = "lb_sahipSakin";
			this.lb_sahipSakin.Size = new System.Drawing.Size(126, 13);
			this.lb_sahipSakin.TabIndex = 1;
			this.lb_sahipSakin.Text = "*Daire Sahibi/Sakini:";
			// 
			// cb_sahipSakin
			// 
			this.cb_sahipSakin.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cb_sahipSakin.FormattingEnabled = true;
			this.cb_sahipSakin.Items.AddRange(new object[] {
            "-",
            "Sahip",
            "Kiracı"});
			this.cb_sahipSakin.Location = new System.Drawing.Point(166, 48);
			this.cb_sahipSakin.Name = "cb_sahipSakin";
			this.cb_sahipSakin.Size = new System.Drawing.Size(101, 21);
			this.cb_sahipSakin.TabIndex = 1;
			// 
			// lb_ad
			// 
			this.lb_ad.AutoSize = true;
			this.lb_ad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lb_ad.ForeColor = System.Drawing.Color.MidnightBlue;
			this.lb_ad.Location = new System.Drawing.Point(129, 78);
			this.lb_ad.Name = "lb_ad";
			this.lb_ad.Size = new System.Drawing.Size(31, 13);
			this.lb_ad.TabIndex = 4;
			this.lb_ad.Text = "*Ad:";
			// 
			// lb_soyad
			// 
			this.lb_soyad.AutoSize = true;
			this.lb_soyad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lb_soyad.ForeColor = System.Drawing.Color.MidnightBlue;
			this.lb_soyad.Location = new System.Drawing.Point(109, 104);
			this.lb_soyad.Name = "lb_soyad";
			this.lb_soyad.Size = new System.Drawing.Size(51, 13);
			this.lb_soyad.TabIndex = 5;
			this.lb_soyad.Text = "*Soyad:";
			// 
			// tb_ad
			// 
			this.tb_ad.Location = new System.Drawing.Point(166, 75);
			this.tb_ad.MaxLength = 25;
			this.tb_ad.Name = "tb_ad";
			this.tb_ad.Size = new System.Drawing.Size(100, 20);
			this.tb_ad.TabIndex = 2;
			// 
			// tb_soyad
			// 
			this.tb_soyad.Location = new System.Drawing.Point(166, 101);
			this.tb_soyad.MaxLength = 25;
			this.tb_soyad.Name = "tb_soyad";
			this.tb_soyad.Size = new System.Drawing.Size(100, 20);
			this.tb_soyad.TabIndex = 3;
			// 
			// lb_telefon
			// 
			this.lb_telefon.AutoSize = true;
			this.lb_telefon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lb_telefon.ForeColor = System.Drawing.Color.MidnightBlue;
			this.lb_telefon.Location = new System.Drawing.Point(70, 130);
			this.lb_telefon.Name = "lb_telefon";
			this.lb_telefon.Size = new System.Drawing.Size(90, 13);
			this.lb_telefon.TabIndex = 8;
			this.lb_telefon.Text = "*Telefon No 1:";
			// 
			// tb_telno1
			// 
			this.tb_telno1.Location = new System.Drawing.Point(167, 127);
			this.tb_telno1.MaxLength = 12;
			this.tb_telno1.Name = "tb_telno1";
			this.tb_telno1.Size = new System.Drawing.Size(100, 20);
			this.tb_telno1.TabIndex = 4;
			// 
			// lb_isAdresi
			// 
			this.lb_isAdresi.AutoSize = true;
			this.lb_isAdresi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lb_isAdresi.ForeColor = System.Drawing.Color.MidnightBlue;
			this.lb_isAdresi.Location = new System.Drawing.Point(100, 234);
			this.lb_isAdresi.Name = "lb_isAdresi";
			this.lb_isAdresi.Size = new System.Drawing.Size(60, 13);
			this.lb_isAdresi.TabIndex = 10;
			this.lb_isAdresi.Text = "İş Adresi:";
			// 
			// tb_isAdresi
			// 
			this.tb_isAdresi.Location = new System.Drawing.Point(166, 231);
			this.tb_isAdresi.MaxLength = 100;
			this.tb_isAdresi.Multiline = true;
			this.tb_isAdresi.Name = "tb_isAdresi";
			this.tb_isAdresi.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
			this.tb_isAdresi.Size = new System.Drawing.Size(183, 66);
			this.tb_isAdresi.TabIndex = 8;
			// 
			// lb_aciklama
			// 
			this.lb_aciklama.AutoSize = true;
			this.lb_aciklama.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lb_aciklama.ForeColor = System.Drawing.Color.MidnightBlue;
			this.lb_aciklama.Location = new System.Drawing.Point(98, 306);
			this.lb_aciklama.Name = "lb_aciklama";
			this.lb_aciklama.Size = new System.Drawing.Size(62, 13);
			this.lb_aciklama.TabIndex = 18;
			this.lb_aciklama.Text = "Açıklama:";
			// 
			// tb_aciklama
			// 
			this.tb_aciklama.Location = new System.Drawing.Point(166, 303);
			this.tb_aciklama.MaxLength = 250;
			this.tb_aciklama.Multiline = true;
			this.tb_aciklama.Name = "tb_aciklama";
			this.tb_aciklama.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
			this.tb_aciklama.Size = new System.Drawing.Size(184, 57);
			this.tb_aciklama.TabIndex = 9;
			// 
			// bt_onayla
			// 
			this.bt_onayla.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.bt_onayla.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.bt_onayla.ForeColor = System.Drawing.Color.MidnightBlue;
			this.bt_onayla.Location = new System.Drawing.Point(142, 373);
			this.bt_onayla.Name = "bt_onayla";
			this.bt_onayla.Size = new System.Drawing.Size(101, 41);
			this.bt_onayla.TabIndex = 10;
			this.bt_onayla.Text = "Onayla";
			this.bt_onayla.UseVisualStyleBackColor = false;
			this.bt_onayla.Click += new System.EventHandler(this.bt_onayla_Click);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.BackColor = System.Drawing.Color.MidnightBlue;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaption;
			this.label3.Location = new System.Drawing.Point(-8, 9);
			this.label3.MinimumSize = new System.Drawing.Size(400, 24);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(400, 24);
			this.label3.TabIndex = 30;
			this.label3.Text = "Kişiler";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// tb_telno2
			// 
			this.tb_telno2.Location = new System.Drawing.Point(166, 153);
			this.tb_telno2.MaxLength = 12;
			this.tb_telno2.Name = "tb_telno2";
			this.tb_telno2.Size = new System.Drawing.Size(100, 20);
			this.tb_telno2.TabIndex = 5;
			// 
			// tb_telno3
			// 
			this.tb_telno3.Location = new System.Drawing.Point(166, 179);
			this.tb_telno3.MaxLength = 12;
			this.tb_telno3.Name = "tb_telno3";
			this.tb_telno3.Size = new System.Drawing.Size(100, 20);
			this.tb_telno3.TabIndex = 6;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
			this.label1.Location = new System.Drawing.Point(75, 156);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(85, 13);
			this.label1.TabIndex = 33;
			this.label1.Text = "Telefon No 2:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label2.ForeColor = System.Drawing.Color.MidnightBlue;
			this.label2.Location = new System.Drawing.Point(75, 182);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(85, 13);
			this.label2.TabIndex = 34;
			this.label2.Text = "Telefon No 3:";
			// 
			// tb_eposta
			// 
			this.tb_eposta.Location = new System.Drawing.Point(166, 205);
			this.tb_eposta.MaxLength = 50;
			this.tb_eposta.Name = "tb_eposta";
			this.tb_eposta.Size = new System.Drawing.Size(183, 20);
			this.tb_eposta.TabIndex = 7;
			// 
			// lb_eposta
			// 
			this.lb_eposta.AutoSize = true;
			this.lb_eposta.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lb_eposta.ForeColor = System.Drawing.Color.MidnightBlue;
			this.lb_eposta.Location = new System.Drawing.Point(105, 208);
			this.lb_eposta.Name = "lb_eposta";
			this.lb_eposta.Size = new System.Drawing.Size(55, 13);
			this.lb_eposta.TabIndex = 36;
			this.lb_eposta.Text = "E-Posta:";
			// 
			// KisiEkle
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.InactiveCaption;
			this.ClientSize = new System.Drawing.Size(384, 426);
			this.Controls.Add(this.lb_eposta);
			this.Controls.Add(this.tb_eposta);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.tb_telno3);
			this.Controls.Add(this.tb_telno2);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.bt_onayla);
			this.Controls.Add(this.tb_aciklama);
			this.Controls.Add(this.lb_aciklama);
			this.Controls.Add(this.tb_isAdresi);
			this.Controls.Add(this.lb_isAdresi);
			this.Controls.Add(this.tb_telno1);
			this.Controls.Add(this.lb_telefon);
			this.Controls.Add(this.tb_soyad);
			this.Controls.Add(this.tb_ad);
			this.Controls.Add(this.lb_soyad);
			this.Controls.Add(this.lb_ad);
			this.Controls.Add(this.cb_sahipSakin);
			this.Controls.Add(this.lb_sahipSakin);
			this.MaximumSize = new System.Drawing.Size(400, 465);
			this.MinimumSize = new System.Drawing.Size(400, 465);
			this.Name = "KisiEkle";
			this.Text = "Kişiler";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Label lb_sahipSakin;
		private System.Windows.Forms.ComboBox cb_sahipSakin;
		private System.Windows.Forms.Label lb_ad;
		private System.Windows.Forms.Label lb_soyad;
		private System.Windows.Forms.TextBox tb_ad;
		private System.Windows.Forms.TextBox tb_soyad;
		private System.Windows.Forms.Label lb_telefon;
		private System.Windows.Forms.TextBox tb_telno1;
		private System.Windows.Forms.Label lb_isAdresi;
		private System.Windows.Forms.TextBox tb_isAdresi;
		private System.Windows.Forms.Label lb_aciklama;
		private System.Windows.Forms.TextBox tb_aciklama;
		private System.Windows.Forms.Button bt_onayla;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox tb_telno2;
		private System.Windows.Forms.TextBox tb_telno3;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox tb_eposta;
		private System.Windows.Forms.Label lb_eposta;
	}
}