﻿namespace ApartmanYönetimSistemi
{
	partial class AnaEkran
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.gb_islemler = new System.Windows.Forms.GroupBox();
			this.bt_yardimTalebi = new System.Windows.Forms.Button();
			this.bt_sifreDegistir = new System.Windows.Forms.Button();
			this.bt_yakitGoruntule = new System.Windows.Forms.Button();
			this.bt_aidatGoruntule = new System.Windows.Forms.Button();
			this.bt_siteGiderleri = new System.Windows.Forms.Button();
			this.bt_aracGoruntule = new System.Windows.Forms.Button();
			this.bt_kisiGoruntule = new System.Windows.Forms.Button();
			this.bt_daireGoruntule = new System.Windows.Forms.Button();
			this.statusStrip1 = new System.Windows.Forms.StatusStrip();
			this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
			this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.düzenleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.silToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.dosyaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.çıkışToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.görüntüleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.daireleriGörüntüleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.kişileriGörüntüleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.araçlarıGörüntüleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.aidatGirdileriniGörüntüleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.yakıtGirdileriniGörüntüleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.giderleriGörüntüleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.yardımToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.hakkındaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.label1 = new System.Windows.Forms.Label();
			this.gb_islemler.SuspendLayout();
			this.statusStrip1.SuspendLayout();
			this.contextMenuStrip1.SuspendLayout();
			this.menuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// gb_islemler
			// 
			this.gb_islemler.BackColor = System.Drawing.SystemColors.InactiveCaption;
			this.gb_islemler.Controls.Add(this.bt_yardimTalebi);
			this.gb_islemler.Controls.Add(this.bt_sifreDegistir);
			this.gb_islemler.Controls.Add(this.bt_yakitGoruntule);
			this.gb_islemler.Controls.Add(this.bt_aidatGoruntule);
			this.gb_islemler.Controls.Add(this.bt_siteGiderleri);
			this.gb_islemler.Controls.Add(this.bt_aracGoruntule);
			this.gb_islemler.Controls.Add(this.bt_kisiGoruntule);
			this.gb_islemler.Controls.Add(this.bt_daireGoruntule);
			this.gb_islemler.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.gb_islemler.ForeColor = System.Drawing.Color.MidnightBlue;
			this.gb_islemler.Location = new System.Drawing.Point(88, 79);
			this.gb_islemler.Name = "gb_islemler";
			this.gb_islemler.Size = new System.Drawing.Size(219, 213);
			this.gb_islemler.TabIndex = 2;
			this.gb_islemler.TabStop = false;
			this.gb_islemler.Text = "İşlemler";
			// 
			// bt_yardimTalebi
			// 
			this.bt_yardimTalebi.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.bt_yardimTalebi.ForeColor = System.Drawing.Color.MidnightBlue;
			this.bt_yardimTalebi.Location = new System.Drawing.Point(112, 160);
			this.bt_yardimTalebi.Name = "bt_yardimTalebi";
			this.bt_yardimTalebi.Size = new System.Drawing.Size(100, 41);
			this.bt_yardimTalebi.TabIndex = 8;
			this.bt_yardimTalebi.Text = "Yazılım Hakkında";
			this.bt_yardimTalebi.UseVisualStyleBackColor = false;
			this.bt_yardimTalebi.Click += new System.EventHandler(this.bt_yardimTalebi_Click);
			// 
			// bt_sifreDegistir
			// 
			this.bt_sifreDegistir.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.bt_sifreDegistir.ForeColor = System.Drawing.Color.MidnightBlue;
			this.bt_sifreDegistir.Location = new System.Drawing.Point(7, 160);
			this.bt_sifreDegistir.Name = "bt_sifreDegistir";
			this.bt_sifreDegistir.Size = new System.Drawing.Size(100, 41);
			this.bt_sifreDegistir.TabIndex = 4;
			this.bt_sifreDegistir.Text = "Kullanıcı Şifresi Değiştir";
			this.bt_sifreDegistir.UseVisualStyleBackColor = false;
			this.bt_sifreDegistir.Click += new System.EventHandler(this.bt_sifreDegistir_Click);
			// 
			// bt_yakitGoruntule
			// 
			this.bt_yakitGoruntule.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.bt_yakitGoruntule.ForeColor = System.Drawing.Color.MidnightBlue;
			this.bt_yakitGoruntule.Location = new System.Drawing.Point(6, 66);
			this.bt_yakitGoruntule.Name = "bt_yakitGoruntule";
			this.bt_yakitGoruntule.Size = new System.Drawing.Size(101, 41);
			this.bt_yakitGoruntule.TabIndex = 2;
			this.bt_yakitGoruntule.Tag = "Yakit";
			this.bt_yakitGoruntule.Text = "Yakıt Girdilerini Görüntüle";
			this.bt_yakitGoruntule.UseVisualStyleBackColor = false;
			this.bt_yakitGoruntule.Click += new System.EventHandler(this.bt_yakitGoruntule_Click);
			// 
			// bt_aidatGoruntule
			// 
			this.bt_aidatGoruntule.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.bt_aidatGoruntule.ForeColor = System.Drawing.Color.MidnightBlue;
			this.bt_aidatGoruntule.Location = new System.Drawing.Point(112, 66);
			this.bt_aidatGoruntule.Name = "bt_aidatGoruntule";
			this.bt_aidatGoruntule.Size = new System.Drawing.Size(101, 41);
			this.bt_aidatGoruntule.TabIndex = 6;
			this.bt_aidatGoruntule.Tag = "Aidat";
			this.bt_aidatGoruntule.Text = "Aidat Girdilerini Görüntüle";
			this.bt_aidatGoruntule.UseVisualStyleBackColor = false;
			this.bt_aidatGoruntule.Click += new System.EventHandler(this.bt_aidatGoruntule_Click);
			// 
			// bt_siteGiderleri
			// 
			this.bt_siteGiderleri.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.bt_siteGiderleri.ForeColor = System.Drawing.Color.MidnightBlue;
			this.bt_siteGiderleri.Location = new System.Drawing.Point(112, 113);
			this.bt_siteGiderleri.Name = "bt_siteGiderleri";
			this.bt_siteGiderleri.Size = new System.Drawing.Size(100, 41);
			this.bt_siteGiderleri.TabIndex = 7;
			this.bt_siteGiderleri.Tag = "Giderler";
			this.bt_siteGiderleri.Text = "Site Giderlerini Görüntüle";
			this.bt_siteGiderleri.UseVisualStyleBackColor = false;
			this.bt_siteGiderleri.Click += new System.EventHandler(this.bt_siteGiderleri_Click);
			// 
			// bt_aracGoruntule
			// 
			this.bt_aracGoruntule.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.bt_aracGoruntule.ForeColor = System.Drawing.Color.MidnightBlue;
			this.bt_aracGoruntule.Location = new System.Drawing.Point(7, 113);
			this.bt_aracGoruntule.Name = "bt_aracGoruntule";
			this.bt_aracGoruntule.Size = new System.Drawing.Size(101, 41);
			this.bt_aracGoruntule.TabIndex = 3;
			this.bt_aracGoruntule.Tag = "Arac";
			this.bt_aracGoruntule.Text = "Taşıtları Görüntüle";
			this.bt_aracGoruntule.UseVisualStyleBackColor = false;
			this.bt_aracGoruntule.Click += new System.EventHandler(this.bt_aracGoruntule_Click);
			// 
			// bt_kisiGoruntule
			// 
			this.bt_kisiGoruntule.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.bt_kisiGoruntule.ForeColor = System.Drawing.Color.MidnightBlue;
			this.bt_kisiGoruntule.Location = new System.Drawing.Point(113, 19);
			this.bt_kisiGoruntule.Name = "bt_kisiGoruntule";
			this.bt_kisiGoruntule.Size = new System.Drawing.Size(101, 41);
			this.bt_kisiGoruntule.TabIndex = 5;
			this.bt_kisiGoruntule.Tag = "Kisi";
			this.bt_kisiGoruntule.Text = "Kişileri Görüntüle";
			this.bt_kisiGoruntule.UseVisualStyleBackColor = false;
			this.bt_kisiGoruntule.Click += new System.EventHandler(this.bt_kisiGoruntule_Click);
			// 
			// bt_daireGoruntule
			// 
			this.bt_daireGoruntule.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.bt_daireGoruntule.ForeColor = System.Drawing.Color.MidnightBlue;
			this.bt_daireGoruntule.Location = new System.Drawing.Point(6, 19);
			this.bt_daireGoruntule.Name = "bt_daireGoruntule";
			this.bt_daireGoruntule.Size = new System.Drawing.Size(101, 41);
			this.bt_daireGoruntule.TabIndex = 1;
			this.bt_daireGoruntule.Tag = "Daire";
			this.bt_daireGoruntule.Text = "Daireleri Görüntüle";
			this.bt_daireGoruntule.UseVisualStyleBackColor = false;
			this.bt_daireGoruntule.Click += new System.EventHandler(this.bt_daireGoruntule_Click);
			// 
			// statusStrip1
			// 
			this.statusStrip1.BackColor = System.Drawing.SystemColors.Control;
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
			this.statusStrip1.Location = new System.Drawing.Point(0, 304);
			this.statusStrip1.Name = "statusStrip1";
			this.statusStrip1.Size = new System.Drawing.Size(394, 22);
			this.statusStrip1.TabIndex = 4;
			this.statusStrip1.Text = "Hazır";
			// 
			// toolStripStatusLabel1
			// 
			this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
			this.toolStripStatusLabel1.Size = new System.Drawing.Size(90, 17);
			this.toolStripStatusLabel1.Text = "Kullanıma Hazır";
			// 
			// contextMenuStrip1
			// 
			this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.düzenleToolStripMenuItem,
            this.silToolStripMenuItem});
			this.contextMenuStrip1.Name = "contextMenuStrip1";
			this.contextMenuStrip1.Size = new System.Drawing.Size(117, 48);
			// 
			// düzenleToolStripMenuItem
			// 
			this.düzenleToolStripMenuItem.Name = "düzenleToolStripMenuItem";
			this.düzenleToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
			this.düzenleToolStripMenuItem.Text = "Düzenle";
			// 
			// silToolStripMenuItem
			// 
			this.silToolStripMenuItem.Name = "silToolStripMenuItem";
			this.silToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
			this.silToolStripMenuItem.Text = "Sil";
			// 
			// menuStrip1
			// 
			this.menuStrip1.BackColor = System.Drawing.SystemColors.Control;
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dosyaToolStripMenuItem,
            this.görüntüleToolStripMenuItem,
            this.yardımToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(394, 24);
			this.menuStrip1.TabIndex = 6;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// dosyaToolStripMenuItem
			// 
			this.dosyaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.çıkışToolStripMenuItem});
			this.dosyaToolStripMenuItem.Name = "dosyaToolStripMenuItem";
			this.dosyaToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
			this.dosyaToolStripMenuItem.Text = "Dosya";
			// 
			// çıkışToolStripMenuItem
			// 
			this.çıkışToolStripMenuItem.Name = "çıkışToolStripMenuItem";
			this.çıkışToolStripMenuItem.ShortcutKeyDisplayString = "Alt+F4";
			this.çıkışToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
			this.çıkışToolStripMenuItem.Text = "Çıkış";
			this.çıkışToolStripMenuItem.Click += new System.EventHandler(this.çıkışToolStripMenuItem_Click);
			// 
			// görüntüleToolStripMenuItem
			// 
			this.görüntüleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.daireleriGörüntüleToolStripMenuItem,
            this.kişileriGörüntüleToolStripMenuItem,
            this.araçlarıGörüntüleToolStripMenuItem,
            this.aidatGirdileriniGörüntüleToolStripMenuItem,
            this.yakıtGirdileriniGörüntüleToolStripMenuItem,
            this.giderleriGörüntüleToolStripMenuItem});
			this.görüntüleToolStripMenuItem.Name = "görüntüleToolStripMenuItem";
			this.görüntüleToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
			this.görüntüleToolStripMenuItem.Text = "Görüntüle";
			// 
			// daireleriGörüntüleToolStripMenuItem
			// 
			this.daireleriGörüntüleToolStripMenuItem.Name = "daireleriGörüntüleToolStripMenuItem";
			this.daireleriGörüntüleToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+D";
			this.daireleriGörüntüleToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
			this.daireleriGörüntüleToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
			this.daireleriGörüntüleToolStripMenuItem.Text = "Daireleri Görüntüle";
			this.daireleriGörüntüleToolStripMenuItem.Click += new System.EventHandler(this.bt_daireGoruntule_Click);
			// 
			// kişileriGörüntüleToolStripMenuItem
			// 
			this.kişileriGörüntüleToolStripMenuItem.Name = "kişileriGörüntüleToolStripMenuItem";
			this.kişileriGörüntüleToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+K";
			this.kişileriGörüntüleToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.K)));
			this.kişileriGörüntüleToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
			this.kişileriGörüntüleToolStripMenuItem.Text = "Kişileri Görüntüle";
			this.kişileriGörüntüleToolStripMenuItem.Click += new System.EventHandler(this.bt_kisiGoruntule_Click);
			// 
			// araçlarıGörüntüleToolStripMenuItem
			// 
			this.araçlarıGörüntüleToolStripMenuItem.Name = "araçlarıGörüntüleToolStripMenuItem";
			this.araçlarıGörüntüleToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+T";
			this.araçlarıGörüntüleToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
			this.araçlarıGörüntüleToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
			this.araçlarıGörüntüleToolStripMenuItem.Text = "Araçları Görüntüle";
			this.araçlarıGörüntüleToolStripMenuItem.Click += new System.EventHandler(this.bt_aracGoruntule_Click);
			// 
			// aidatGirdileriniGörüntüleToolStripMenuItem
			// 
			this.aidatGirdileriniGörüntüleToolStripMenuItem.Name = "aidatGirdileriniGörüntüleToolStripMenuItem";
			this.aidatGirdileriniGörüntüleToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+A";
			this.aidatGirdileriniGörüntüleToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
			this.aidatGirdileriniGörüntüleToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
			this.aidatGirdileriniGörüntüleToolStripMenuItem.Text = "Aidat Girdilerini Görüntüle";
			this.aidatGirdileriniGörüntüleToolStripMenuItem.Click += new System.EventHandler(this.bt_aidatGoruntule_Click);
			// 
			// yakıtGirdileriniGörüntüleToolStripMenuItem
			// 
			this.yakıtGirdileriniGörüntüleToolStripMenuItem.Name = "yakıtGirdileriniGörüntüleToolStripMenuItem";
			this.yakıtGirdileriniGörüntüleToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+Y";
			this.yakıtGirdileriniGörüntüleToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y)));
			this.yakıtGirdileriniGörüntüleToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
			this.yakıtGirdileriniGörüntüleToolStripMenuItem.Text = "Yakıt Girdilerini Görüntüle";
			this.yakıtGirdileriniGörüntüleToolStripMenuItem.Click += new System.EventHandler(this.bt_yakitGoruntule_Click);
			// 
			// giderleriGörüntüleToolStripMenuItem
			// 
			this.giderleriGörüntüleToolStripMenuItem.Name = "giderleriGörüntüleToolStripMenuItem";
			this.giderleriGörüntüleToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+G";
			this.giderleriGörüntüleToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
			this.giderleriGörüntüleToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
			this.giderleriGörüntüleToolStripMenuItem.Text = "Giderleri Görüntüle";
			// 
			// yardımToolStripMenuItem
			// 
			this.yardımToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hakkındaToolStripMenuItem});
			this.yardımToolStripMenuItem.Name = "yardımToolStripMenuItem";
			this.yardımToolStripMenuItem.ShortcutKeyDisplayString = "";
			this.yardımToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
			this.yardımToolStripMenuItem.Text = "Yardım";
			// 
			// hakkındaToolStripMenuItem
			// 
			this.hakkındaToolStripMenuItem.Name = "hakkındaToolStripMenuItem";
			this.hakkındaToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+Alt+H";
			this.hakkındaToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Alt) 
            | System.Windows.Forms.Keys.H)));
			this.hakkındaToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
			this.hakkındaToolStripMenuItem.Text = "Hakkında";
			this.hakkındaToolStripMenuItem.Click += new System.EventHandler(this.hakkındaToolStripMenuItem_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.MidnightBlue;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
			this.label1.Location = new System.Drawing.Point(0, 36);
			this.label1.MinimumSize = new System.Drawing.Size(400, 25);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(400, 25);
			this.label1.TabIndex = 7;
			this.label1.Text = "Bahçeşehir Konutları 3. Etap";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// AnaEkran
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.InactiveCaption;
			this.ClientSize = new System.Drawing.Size(394, 326);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.statusStrip1);
			this.Controls.Add(this.menuStrip1);
			this.Controls.Add(this.gb_islemler);
			this.MainMenuStrip = this.menuStrip1;
			this.MaximumSize = new System.Drawing.Size(410, 365);
			this.MinimumSize = new System.Drawing.Size(410, 365);
			this.Name = "AnaEkran";
			this.Text = "Bahçeşehir Konutları 3. Etap - KKY Site Yönetim Sistemi";
			this.gb_islemler.ResumeLayout(false);
			this.statusStrip1.ResumeLayout(false);
			this.statusStrip1.PerformLayout();
			this.contextMenuStrip1.ResumeLayout(false);
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.GroupBox gb_islemler;
		private System.Windows.Forms.Button bt_yakitGoruntule;
		private System.Windows.Forms.Button bt_aidatGoruntule;
		private System.Windows.Forms.Button bt_aracGoruntule;
		private System.Windows.Forms.Button bt_kisiGoruntule;
		private System.Windows.Forms.Button bt_daireGoruntule;
		private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
		private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
		private System.Windows.Forms.ToolStripMenuItem düzenleToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem silToolStripMenuItem;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem dosyaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem çıkışToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem yardımToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem hakkındaToolStripMenuItem;
		private System.Windows.Forms.Button bt_yardimTalebi;
		private System.Windows.Forms.Button bt_sifreDegistir;
		private System.Windows.Forms.ToolStripMenuItem görüntüleToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem daireleriGörüntüleToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem kişileriGörüntüleToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem araçlarıGörüntüleToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem aidatGirdileriniGörüntüleToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem yakıtGirdileriniGörüntüleToolStripMenuItem;
		private System.Windows.Forms.Button bt_siteGiderleri;
		private System.Windows.Forms.ToolStripMenuItem giderleriGörüntüleToolStripMenuItem;
		private System.Windows.Forms.Label label1;
	}
}