# Apartman Yönetim Sistemi 180320

.NET Framework v4.6.1 baz alınarak ADO.NET teknolojisi ile Access veritabanı kullanılmıştır. Çok katmanlı mimari ile çalışılmıştır. IslemKatmani'nda veritabanı bağlantısı, veri yazma ve okuma, verileri Excel dosyasına yazma gibi işlemlerin yürütüldüğü kodlar mevcuttur. KayitKatmani'nda veritabanı modeli olarak kullanılan sınıflar ve nitelikleri mevcuttur.


Sistemin Bileşenleri -> Daire, Eski Daire, Araç, Kişi, Aidat, Yakıt ve Gider kayıtlarının eklenmesi, düzeltilmesi, silinmesi ve tutulmasını kapsamaktadır. Frame açıldığında bir DataGridView üzerinde veriler tablo şeklinde gösterilmektedir.


GNU General Public License v3.0 lisanslıdır. Kullanım hakları ad belirtmek koşulu ile özgürdür!


İstek üzerine geliştirilmiştir fakat proje web üzerinden devam ettirileceği için kaynak kodları paylaşılmıştır. Veritabanı dosyası paylaşılmamıştır...


Not: Yeni bir daire kaydı oluşturmak için öncelikle bir kişi kaydı oluşturmanız gerekmektedir. Dairenin sahibi ve sakini nitelikleri DropDownList ile kişi listesini gösterdiği için bu zorunludur.

