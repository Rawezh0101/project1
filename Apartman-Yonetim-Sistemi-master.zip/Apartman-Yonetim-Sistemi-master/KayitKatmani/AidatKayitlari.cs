﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KayitKatmani
{
	public class AidatKayitlari
	{
		public int AidatNo { get; set; }
		public int DaireNo { get; set; }
		public string Tarih { get; set; }
		public int AidatTutar { get; set; }
		public int OrtakTutar { get; set; }
		public int Demirbas { get; set; }
		public int ToplamTutar { get; set; }
	}
}
