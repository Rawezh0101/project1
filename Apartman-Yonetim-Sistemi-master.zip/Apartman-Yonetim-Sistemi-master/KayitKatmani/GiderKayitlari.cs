﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KayitKatmani
{
	public class GiderKayitlari
	{
		public int GiderID { get; set; }
		public string GiderTuru { get; set; }
		public int Tutar { get; set; }
		public string Tarih { get; set; }
		public string Aciklama { get; set; }
	}
}
