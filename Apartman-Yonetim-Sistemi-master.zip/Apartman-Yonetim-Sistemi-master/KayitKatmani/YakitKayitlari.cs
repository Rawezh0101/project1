﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KayitKatmani
{
	public class YakitKayitlari
	{
		public int YakitNo { get; set; }
		public int DaireNo { get; set; }
		public string Tarih { get; set; }
		public int Tutar { get; set; }
		public int OdenenKontorMiktari { get; set; }
	}
}
