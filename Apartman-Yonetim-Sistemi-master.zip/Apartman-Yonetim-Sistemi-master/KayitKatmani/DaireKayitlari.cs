﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KayitKatmani
{
	public class DaireKayitlari
	{
		public int DaireNo { get; set; }
		public string DaireDurum { get; set; }
		public string DaireSahibi { get; set; }
		public string DaireSakini { get; set; }
		public int Kat { get; set; }
	}
}
