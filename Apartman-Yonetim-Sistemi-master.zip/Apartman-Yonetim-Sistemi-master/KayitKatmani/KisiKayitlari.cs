﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KayitKatmani
{
    public class KisiKayitlari
    {
		public int KisiID { get; set; }
		public string Durum { get; set; }
		public string Ad { get; set; }
		public string Soyad { get; set; }
		public string TelefonNo1 { get; set; }
		public string TelefonNo2 { get; set; }
		public string TelefonNo3 { get; set; }
		public string Eposta { get; set; }
		public string IsAdresi { get; set; }
		public string Aciklama { get; set; }
	}
}
