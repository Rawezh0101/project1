﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KayitKatmani
{
	public class EskiDaireKayitlari
	{
		public int KayitID { get; set; }
		public int DaireNo { get; set; }
		public string DaireSahibi { get; set; }
		public string DaireSakini { get; set; }
		public string GirisTarihi { get; set; }
		public string CikisTarihi { get; set; }
		public string Aciklama { get; set; }
	}
}
