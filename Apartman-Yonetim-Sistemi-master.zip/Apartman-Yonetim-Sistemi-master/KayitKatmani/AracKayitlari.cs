﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KayitKatmani
{
	public class AracKayitlari
	{
		public string AracPlaka { get; set; }
		public string Marka { get; set; }
		public string Model { get; set; }
		public int DaireNo { get; set; }
		public string TelefonNo { get; set; }
	}
}
